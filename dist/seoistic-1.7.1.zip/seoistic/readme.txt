=== SEOistic ===
Contributors: wordpressistic
Tags: seo, schema, sitemap, redirects, indexing
Requires at least: 6.4
Tested up to: 7.0
Requires PHP: 8.1
Stable tag: 1.7.1
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

On-page SEO analysis, schema, sitemaps, redirects, fast indexing, and WPistic AI-assisted optimization.

== Description ==

SEOistic is a WordPress SEO plugin: on-page analysis and scoring, schema
(structured data), XML sitemaps, robots and canonical control, redirects
with a 404 monitor, image SEO, fast/instant search-engine indexing (Google
Indexing API + IndexNow, branded Indexistic), and AI-assisted content
optimization through the WPistic AI service (included with Pro, credit-
metered) — or your own OpenAI-compatible endpoint with a custom API key.

= Free features =

* A deterministic, versioned 0-100 SEO score per post, with live feedback
  while you edit (title, meta description, focus keyword placement, heading
  structure, internal links, image alt text, content length, share image).
* Google desktop/mobile and social-share search-appearance previews.
* Schema.org JSON-LD (Organization, WebSite, per-page types), validated
  against each type's required/recommended properties.
* XML sitemaps, robots.txt, canonical URLs, breadcrumbs, and llms.txt.
* Redirects with a 404 monitor and CSV import/export.
* Fast indexing (Indexistic): submit published/updated URLs to Google's
  Indexing API and the free IndexNow protocol (Bing, Yandex, Seznam,
  Naver), automatically on publish (opt-in) or from a bulk console.
* Content Health: orphan-page detection and content-decay flagging, both
  linking straight to the editor rather than auto-applying anything.
* Importers for Yoast SEO, Rank Math, and AIOSEO metadata.
* WooCommerce and basic local-business SEO fields.

= Premium features (license required) =

AI-assisted generation (WPistic AI credits, or your own OpenAI-compatible
endpoint), a visual schema builder, Core Web Vitals monitoring, AI
search-visibility / AEO reporting, a keyword rank tracker, a read-only
Google Search Console dashboard, GA4/Search Console/PageSpeed Connections,
a Domain & Uptime Monitor, and the approval-gated Business Automator.
Current plans and pricing — with working checkout — live on the Upgrade
screen inside the plugin and at https://www.wordpressistic.com/pricing/.

= AI generation is always explicit and previewed =

Every AI suggestion — title, description, keywords, schema type, alt text,
content improvements — is shown as a before/after preview that you must
explicitly apply. Nothing is generated automatically, published
automatically, or written to a field without your action.

== Installation ==

1. In your WordPress admin, go to Plugins > Add New > Upload Plugin.
2. Choose the seoistic-{version}.zip file and click Install Now.
3. Click Activate.
4. A new "SEOistic" item appears in your admin menu.

No Composer install and no build step are required — the plugin runs
directly from the ZIP.

== Frequently Asked Questions ==

= Do I need a license to use SEOistic? =

No. The free tier is fully functional on its own: on-page analysis and
scoring, schema, sitemaps, redirects, image SEO, WooCommerce SEO, local
SEO, fast indexing, and the metadata importers all work without a license.
A license only unlocks the premium addons listed above.

= What happens if the license server is temporarily unreachable? =

Nothing changes immediately. A single failed check doesn't disable your
premium features — SEOistic keeps trusting your last confirmed-active
license for a bounded window while it retries with backoff, and only
applies a genuine change (revoked, expired, wrong site) once the server
actually says so.

= Do I need my own API key for AI features? =

No. Licensed AI features use the WPistic AI gateway and the activation token
issued when the SEOistic license is connected. Business and Agency plans may
optionally connect their own OpenAI-compatible endpoint from the AI settings.

= Does SEOistic phone home or track my site? =

Only what's described in "External Services" below, and only for features
you've actually turned on. There is no analytics/telemetry beacon.

= Where do I manage my license or subscription? =

At https://app.wpistic.com/ — the License screen inside SEOistic links
there directly.

== Screenshots ==

1. Dashboard — SEO health score, optimization roadmap, and quick actions.
2. Post-editor SEO workspace — live score, search preview, and priority fixes.
3. AI suggestion preview — before/after with explicit Apply/Dismiss/Undo.
4. License screen — a two-field activation form.

(Screenshot image files are not included in this release; add them under
this plugin's `/assets` directory following the standard WordPress.org
screenshot-N.png convention before a .org submission.)

== Changelog ==

See CHANGELOG.md in the plugin's source repository for the full history.
Highlights for this release are below.

= 1.7.1 =
* Fixed canonical URL generation for the WordPress posts page and paginated blog archive.
  Archive pages now emit a self-referencing, pagination-aware canonical URL.

= 1.7.0 =
* New addon: Connections — one Google connection for GA4, Search Console
  and PageSpeed data inside SEOISTIC (Pro).
* New addon: Domain & Uptime Monitor — WP-Cron downtime/response-time/SSL
  checks with email alerts (Pro).
* In-plugin checkout: the Upgrade screen now sells plans directly via a
  secure Paddle overlay; plans are aligned with the live WPistic catalog
  (Pro $79/year — every premium addon included).
* IndexNow: the ownership key file now answers with HTTP 200, fixing key
  verification for every participating engine.
* Business Automator: admin page registered (approval queue + recipe
  management), starter recipes now default OFF — no background AI credit
  spend until you enable a recipe.
* Schema Builder: display rules (post types, taxonomies, templates, URL
  patterns) now save and apply correctly instead of injecting site-wide.
* Performance Quick Wins: preview/apply flow fixed — apply no longer fails
  after previewing.
* Content Audit Gate now also enforces on block-editor (REST) publishing.
* AI credits: balance re-syncs on page load and after out-of-credit
  responses; AEO audits update the credits widget instantly.
* Rank Tracker: Search Console mode now records a daily data point, so
  trends and sparklines build real history.
* Custom knowledge file (Settings → AI) is now configurable and restricted
  to uploads-relative paths; Knowledge Base Mode now shapes prompts.
* Redirects work on subdirectory installs and serve rules from cache;
  breadcrumbs honor the metabox "Breadcrumb title"; cron digest emails
  include working edit links; uninstall removes all data (tables, post
  meta, encrypted secrets) including premium options.

= 1.6.5 =
* Keep the HTML sitemap complete, deduplicated, and automatically aligned with published public content.
* Exclude both current noindex metadata and legacy robots noindex values from generated sitemaps.
* Support comma-separated robots directives such as noindex,nofollow.

= 1.6.4 =
* Improve Google Search Console OAuth setup guidance for External/Production apps.
* Isolate concurrent OAuth state tokens so one administrator cannot invalidate another connection attempt.
* Preserve an existing refresh token when Google returns an access token without rotating the refresh token.
* Add the standard granted-scope OAuth parameter and clearer access-blocked guidance.

= 1.6.3 =
* Fix the AI Search REST registration fatal that could block the WordPress admin dashboard on sites using Gutenberg REST preloading.

= 1.6.2 =
* Fix canonical activation-token context for WPistic AI and Search API requests.
* Replace raw WordPress critical-error HTML in AI Tools and Search Console with safe, actionable errors.
* Fix Google OAuth query encoding and improve Rank Tracker connection diagnostics.

= 1.6.0 "Aurora" =
* New addon: AI Search Visibility (AEO) — llms.txt studio, AI crawler analytics, AI-scored AEO audits, citation checklist (Business)
* New addon: Rank Tracker & Reports — keyword positions, sparklines, white-label reports (Business)
* New addon: Schema Pro — visual schema builder with live validation and conditional rules (Pro)
* New addon: Performance & Core Web Vitals — PSI via WPistic proxy, trend cards, threshold alerts, Quick Wins (Pro)
* AI Credits system: all AI runs on the WPistic AI backend — no API keys. Monthly credits per plan with live usage widget; Business/Agency can connect a custom model
* Business Automator: approval-gated recipes with run history and diff preview (Business)
* Google Search Console: real recovery flow for 403 access_denied, refresh-token rotation
* Aurora UI: animated scores, step-trackers, skeletons, toasts, onboarding checklist; respects prefers-reduced-motion


See CHANGELOG.md in the plugin's source repository for the full history.
Highlights for this release are below.

= 1.5.3 =
* Use the WPistic server-assigned plan, including Free, instead of assuming
  every valid license includes Business features.
* Preserve explicit legacy plan mappings; unknown plans fail closed.
* A replacement key cannot inherit another key's paid-plan cache during outages.
* Add 32 automated entitlement regression checks to CI.

= 1.5.2 =
* Premium admin UI redesign: application shell, command palette, dashboard
  roadmap, content inventory, and a live-analysis SEO workspace in the post
  editor.
* Light-mode design system; fixed a CSS specificity bug that rendered some
  button text in a color matching its own background.
* License page simplified to a two-field activation form; license key now
  encrypted at rest; validation distinguishes a temporarily unreachable
  server from an actual revoke/expiry and no longer flips premium features
  off on a single timeout.
* Every upgrade/pricing button now resolves to a real URL by default.
* Fixed a plaintext-secret storage gap in the Business Automator
  integration and a fatal-error bug on its settings screen.
* See CHANGELOG.md for the complete list.

== Upgrade Notice ==

= 1.5.2 =
Admin UI redesign and license-security hardening. No database changes; all
existing SEO metadata, settings, and REST integrations are preserved.

== External Services ==

This plugin connects to the following external services. Each is either
required for a specific feature you've enabled, or (for the license check)
runs only once you've activated a license key.

= WPistic Licensing (wpistic.com) =

Used to activate, validate, and deactivate your SEOistic license. Contacted
when you activate/deactivate a license from the License screen, and once
daily in the background while a license is active, to confirm it's still
valid.

Data sent: your site's home URL, a randomly generated installation ID
(not tied to any personal data), your entered license key, a numeric
product identifier, and the installed plugin version.

This is WordPressistic's own service; see https://wpistic.com/ for
company information. (A direct Terms/Privacy Policy URL for this service
was not available at the time of this release and should be added by the
plugin maintainer before public listing.)

= Google (OAuth, Indexing API, Search Console API) =

Used only if you connect the Indexistic Google Indexing integration
(free) and/or the Search Console addon (premium), each requiring your own
Google Cloud credentials.

Data sent: your own Google service-account or OAuth credentials; the
Indexing API receives the URL of any page you publish/update/delete;
Search Console requests read your existing Search Analytics and URL
Inspection data (never written to).

Google APIs Terms of Service: https://developers.google.com/terms
Google Privacy Policy: https://policies.google.com/privacy

= IndexNow (api.indexnow.org) =

Used only if the free Indexistic addon is enabled, to submit a published
or updated URL for fast indexing by IndexNow's participating engines
(Bing, Yandex, Seznam, Naver).

Data sent: the URL, and a key file this plugin generates and serves at
`/{key}.txt` so the service can verify site ownership.

IndexNow Terms: https://www.indexnow.org/terms

= Bing (www.bing.com) =

Used only if the free Sitemap Extras addon is enabled (pings on publish)
or when you manually use the "ping sitemap" tool, to tell Bing your
sitemap changed.

Data sent: your sitemap's URL.

Microsoft Privacy Statement: https://www.microsoft.com/en-us/privacy/privacystatement

= WPistic AI (ai.wpistic.com) =

Used only when you trigger an AI action (title, description, keywords,
schema, alt text, content optimization, AEO audit) and AI features are
enabled. Requests are authorized with your SEOistic license; credits are
deducted from your plan's monthly allowance.

Data sent: the relevant page/post title, a trimmed content excerpt, and
your site/business context, as part of the generation prompt. Only ever
sent for content you explicitly ask SEOistic to generate/improve. If you
configure your own OpenAI-compatible endpoint (Settings → AI), generation
goes there instead and nothing is sent to ai.wpistic.com.

= Paddle (cdn.paddle.com, buy.paddle.com) =

Used only when you click a Buy Now button on the in-plugin Upgrade screen:
the Paddle.js overlay opens a secure checkout. Data sent: the selected
price ID and, prefilled, the site admin email (editable at checkout).
Payment and license issuance are handled by Paddle and the WPistic
billing webhook — the plugin itself never receives card data.

= Your own Business Automator instance =

Used only if you connect the premium Business Automator addon, to a URL
you configure with an API token you generate on your own instance.

== Privacy ==

SEOistic does not collect or transmit analytics, telemetry, or personal
visitor data. Every integration above is opt-in and requires you to
explicitly connect a provider or activate a license before it contacts
anything. See "External Services" for the complete, code-verified list.
